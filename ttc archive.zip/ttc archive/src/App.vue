<script>
import { RouterLink, RouterView } from 'vue-router'
import Navbar from './components/Navbar.vue'
import Logo from './components/Logo.vue'
import Searchbar from './components/Searchbar.vue'
import Footer from './components/Footer.vue'

export default{
 components : {
  Navbar,
  Logo,
  Searchbar,
  Footer
 },
}

</script>

<template>
  <div class="wrapper">
    <Navbar />
    <RouterView/>
    <Footer/>
  </div>
</template>

<style>
html {
  font-family: 'Signika', sans-serif !important;
}
.wrapper{
  background-color: #0b1120;
  height: 100h;
}
</style>
