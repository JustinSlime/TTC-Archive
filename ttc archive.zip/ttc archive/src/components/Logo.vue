<template>
<div class="container mx-auto py-5">
    <div class="w-10/12 mx-auto py-12 lg:w-6/12">
        <div class="flex flex-col">
            <div class="w-3/12 mx-auto">
                <img src="/images/teslogo.png" alt="" class="w-full">
            </div>
            <div class="flex-col flex text-center text-slate-200 py-4"> 
                <span class="text-4xl">
                    NTTC LIBRARY
                </span>
                <span class="text-xs italic mt-2">
                    BUILDING KNOWLEDGE, ENGINEERING THE FUTURE
                </span>
            </div>
        </div>
    </div>

</div>
</template>

<script>
</script>