<template>
<form action="" @submit.prevent class="w-full">
<div class="px-1 searchBox mx-auto">
    <label class="relative block">
        
        <span class="absolute inset-y-0 right-4 flex items-center pl-2 px-2 py-2 cursor-pointer hover:bg-sky-100 active:bg-sky-200 rounded-lg">
            <font-awesome-icon class="h-5 w-5 fill-slate-300" icon="magnifying-glass"/>
        </span>
        <input class="placeholder:italic placeholder:text-slate-400 block bg-white w-full border border-slate-300 rounded-md py-2 pl-9 pr-12 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" placeholder="Search for Level, Code, Course & Year.." type="text" name="search"/>
    </label>
</div>


</form>

</template>

<script>

</script>

<style>
.searchBox{
    width: 356px;
}
</style>