<template>
    <div class="">
      <div class="flex justify-center">
        <button
        class="bg-sky-900 hover:bg-sky-600 text-white py-3 px-4 rounded-lg text-sm"
        type="submit"
      >
        {{ text }}
      </button>
      </div>
    </div>
  </template>

<script>
export default{
  props: {
    text: {
      type: String
    }
  }
}
</script>

<style scoped>
button {
  width: 356px;
}
@media (max-width: 398px) {
  button{
    width: 300px;
  }
}
@media (max-width: 338px) {
  button{
    width: 250px;
  }
}

</style>