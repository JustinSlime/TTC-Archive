<template>
  <div>
    <div class="w-full flex justify-center flex-wrap">
      <div class="w-full label">
        <label for="" class="text-sm text-slate-200"> {{ label }}</label>
      </div>
      <input
        class="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-sm text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
        :type="type"
        :placeholder="placeholder"
        :value="modelValue"
        @input="$emit('update:modelValue', $event.target.value)"
      />
    </div>
  </div>
</template>

<script>
export default{
    props: {
        label: {
            type: String
        },
        type: {
            type: String
        },
        placeholder: {
            type: String
        },
        modelValue: {
            type: String
        }
    }

}
</script>

<style scoped>
input,
.label {
  width: 356px;
}
::-webkit-input-placeholder {
  /* Edge */
  font-size: small;
}

:-ms-input-placeholder {
  /* Internet Explorer 10-11 */
  font-size: small;
}

::placeholder {
  font-size: small;
}


</style>
