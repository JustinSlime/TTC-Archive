<template>
    <div class="w-full py-4 foot">
        <div class="container mx-auto text-center flex flex-col">
            <span class=" text-slate-200">
                Founded By 2023/2024 Pioneer Students
            </span>

            <span class="text-slate-200 text-xs">
                 @slimedev
            </span>
        </div>
    </div>
</template>

<style>
.foot{
    background-color: #1e293b;
}
</style>
<script>
</script>