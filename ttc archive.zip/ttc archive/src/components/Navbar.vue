<template>
<div>
  <div class="relative">
      <nav>
      <div class="w-full sticky z-10">
        <div class="container mx-auto py-4 flex justify-end">
          <div>
            <span class="bg-zinc-600 py-2 px-3 text-white rounded-sm cursor-pointer" @click="navShow"
              ><font-awesome-icon icon="bars"
            /></span>
          </div>
        </div>
      </div>
      
    </nav>

  <!-- side bar -->
    <div :class="navProperty" class="absolute  top-0 right-0 z-40 w-6/12">
      <div class=" w-full lg:w-3/12 px-3 pt-3 pb-4 ml-auto sideBar rounded-sm">
        <div class="w-full flex justify-end pt-1 pb-2">
          <span class="text-lg px-2 pb-2 pt-1 cursor-pointer text-slate-200" @click="navHide">
            <font-awesome-icon icon="xmark" />
          </span>
        </div>
        <ul>
          
          <li class="mt-1 mb-3 text-slate-200 hover:text-blue-900">
            <font-awesome-icon icon="house" class="px-2" />
            <span class="text-start" @click="hideTap">
              <RouterLink to="/" >Home</RouterLink>
            </span>
          </li>
          
          <li v-for="link in links" :key="link.id" class="text-slate-200 hover:text-blue-900 w-full py-3">
            <div @click="hideTap">
              <span class="px-2 " >
                <font-awesome-icon :icon="link.icon" class="" />
              </span>
              <span class="text-start">
                {{ link.name }}
              </span>
            </div>

          
          </li>

          <li class="mt-3 text-slate-200 hover:text-blue-900">
            <font-awesome-icon icon="user" class="px-2" />
            <span class="text-start" @click="hideTap">
              <RouterLink to="/sign-in" >Sign in</RouterLink>
            </span>
          </li>
          
        </ul>
      </div>
    </div>

      <!-- Content Cover -->
      <div class="coverDiv z-30 opacity-0 absolute" @click="hideDiv" :class="coverProp">

    </div>
  </div>
</div>


</template>

<script>
export default {
  data() {
    return {
      links: [
        {
          id: 1,
          name: 'Levels',
          icon: ['fas', 'stairs']
        },
        {
          id: 2,
          name: 'Courses',
          icon: ['fas', 'book']
        }
      ],
      navProperty: 'hidden',
      coverProp: 'hidden',
      navshow: false,
      text: ''

    }
  },

  methods: {
    
  },
  computed: {
    navShow(){
      if (this.navshow == false){
        this.navProperty = 'fadeIn'
        this.navshow = !this.navshow
        this.coverProp = ''
        
      }
    },

    navHide(){
      if(this.navshow == true){
        this.navProperty = ['fadeOut', 'hidden']
        this.navshow = !this.navshow
        this.coverProp = 'hidden'
      }
    },

    hideTap(){
      this.navProperty = ['fadeOut', 'hidden']
      this.navshow = !this.navshow
      this.coverProp = 'hidden'
    },

    hideDiv(){
      this.coverProp = 'hidden'
      this.navProperty = ['fadeOut', 'hidden']
      this.navshow = !this.navshow
    }
 
   
  }
}
</script>

<style>
.sideBar{
  box-shadow: inset 0 1px 0 0 #ffffff0d;
  background-color: #1e293b;
}
.coverDiv{
  height: 100vh;
  width: 100vw;
  opacity: 0;
}

.fadeIn {
  animation: fade-in 0.5s forwards;
  -webkit-animation: fade-in 0.5s forwards;
  -moz-animation: fade-in 0.5s forwards;
  -o-animation: fade-in 0.5s forwards;

  animation: slide-left 0.5s forwards;
  -webkit-animation: slide-left 0.5s forwards;
  -moz-animation: slide-left 0.5s forwards;
  -o-animation: slide-left 0.5s forwards;
}
.fadeOut {
  animation: fade-out 0.5s forwards;
  -webkit-animation: fade-out 0.5s forwards;
  -moz-animation: fade-out 0.5s forwards;
  -o-animation: fade-out 0.5s forwards;

  animation: slide-right 0.5s forwards;
  -webkit-animation: slide-right 0.5s forwards;
  -moz-animation: slide-right 0.5s forwards;
  -o-animation: slide-right 0.5s forwards;
}
@keyframes fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@-moz-keyframes fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@-o-keyframes fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

@keyframes fade-out {
  100% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
}

@-webkit-keyframes fade-out {
  100% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
}

@-o-keyframes fade-out {
  100% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
}

@-moz-keyframes fade-out {
  100% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
}

@keyframes slide-left {
  0% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(0%);
  }
}
@-o-keyframes slide-left {
  0% {
    -o-transform: translateX(100%);
  }
  100% {
    -o-transform: translateX(0%);
  }
}
@-moz-keyframes slide-left {
  0% {
    -moz-transform: translateX(100%);
  }
  100% {
    -moz-transform: translateX(0%);
  }
}
@-webkit-keyframes slide-left {
  0% {
    -webkit-transform: translateX(100%);
  }
  100% {
    -webkit-transform: translateX(0%);
  }
}

@keyframes slide-right {
  100% {
    transform: translateX(100%);
  }
  0% {
    transform: translateX(0%);
  }
}

@-moz-keyframes slide-right {
  100% {
    -moz-transform: translateX(100%);
  }
  0% {
    -moz-transform: translateX(0%);
  }
}

@-webkit-keyframes slide-right {
  100% {
    -webkit-transform: translateX(100%);
  }
  0% {
    -webkit-transform: translateX(0%);
  }
}

@-o-keyframes slide-right {
  100% {
    -o-transform: translateX(100%);
  }
  0% {
    -o-transform: translateX(0%);
  }
}
</style>


