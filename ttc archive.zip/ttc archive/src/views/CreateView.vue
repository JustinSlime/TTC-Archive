<template>
    <div class="wrap0">
        <div class="text-center py-8">
            <span class="text-slate-200 text-2xl">
            Upload File
            </span>
        </div>
        <form action="" class=" mx-auto">
            <div class=" mx-auto">
                <label class="">
                    <span class="sr-only">Choose profile photo</span>
                    <input type="file" class="block w-full text-sm text-slate-200 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-violet-50 file:text-violet-700 hover:file:bg-blue-100
                    "/>
                </label>
            </div>

            <div class=" mx-auto mt-2 py-2">
                <label for="" class="text-slate-200 "> Select Type Of Document</label>
                <div>
                    <select name="" id="" class="shadow-sm border w-full rounded-lg py-3 px-4 text-sm text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                        <option value="" selected disabled>Select Option</option>
                        <option value="">Past/Mock Question</option>
                        <option value="">Textbooks/Notes</option>
                        
                    </select>
                </div>
            </div>

            <div class=" mx-auto mt-1 py-2">
                <label for="" class="text-slate-200"> Select Level</label>
                <div>
                    <select name="" id="" class="shadow-sm border w-full rounded-lg py-3 px-4 text-sm text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="" selected disabled>Choose Level</option>
                        <option value="">Level 3</option>
                        <option value="">Level 4</option>
                        <option value="">Level 5</option>
                    </select>
                </div>
            </div>

            <div class="mt-3">
                <Input label="Course Name" placeholder="Full name of course"/>
            </div>

            <div class="mt-5">
                <Input label="Course Code (3 digits only)" placeholder="3 digit code of course"/>
            </div>

            <div class="mt-6">
                <Button text="Submit"/>
            </div>


        </form>
    </div>
</template>

<script>
import Input from '../components/Input.vue'
import Button from '../components/Button.vue'

export default{
    components: {
        Input,
        Button
    }
}
</script>

<style>
.wrap0{
    height: 87vh;
}
form{
    width: 356px;
}
</style>