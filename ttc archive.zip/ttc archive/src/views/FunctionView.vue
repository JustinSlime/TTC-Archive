<template>
<div class="wrap8 py-10">
    
   <div class="text-slate-200 flex flex-col justify-center">
    <div class="bg-blue-900 rounded-lg w-6/12 md:w-5/12 lg:w-4/12 mx-auto text-center py-3 mt-8">
        <RouterLink to="/create" class="underline underline-offset-2 px-2 py-2">
            ADD NEW DOCUMENT
        </RouterLink>
    </div>

    <div class="bg-blue-900 rounded-lg w-6/12 md:w-5/12 lg:w-4/12 mx-auto text-center py-3 mt-8">
        <span class="underline underline-offset-2 px-2 py-2">
            DELETE DOCUMENT
        </span>
    </div>
   </div>
</div>
</template>

<script>
import Navbar from '../components/Navbar.vue'
import Footer from '../components/Footer.vue'

export default{

}
</script>

<style>
.wrap8{
    height: 88vh;
}
</style>