<template>
<div class="py-12 px-7 wrap">
    <div class="text-center  py-12 flex flex-col">
        <span class="text-2xl text-slate-500">
            All The Detriments Of This World Stem From A Lack Of Individual Ability. No one is responsible for your weakness, but you.
        </span>
        <span class=" mt-4 text-3xl text-slate-200">
            404 Page Not Found
        </span>

        <span class="text-blue-200 underline underline-offset-2 mt-2">
            <RouterLink to="/">Click Me You Dumbass</RouterLink>
        </span>
    </div>
</div>
</template>

<style>
.wrap{
    height: 88vh;
}
</style>