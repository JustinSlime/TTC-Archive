<template>
<div class="wrap3 py-9">
    <form action="" @submit.prevent class="mx-auto">
        <div class="text-center py-4">
            <span class="text-slate-200 text-3xl">
                ADMIN ACCESS ONLY
            </span>
        </div>

        <div class="py-8">
            <div >
                <Input label="Username" placeholder="Fill in Username" type="text" v-model="form.username"/>
            </div>

            <div class="mt-7">
                <Input label="Password" placeholder="Fill in Password"/>
            </div>

            <div class="mt-8">
                <Button text="Sign In"/>
            </div>
        </div>


    </form>
</div>
</template>

<script>
import Input from '../components/Input.vue'
import Button from '../components/Button.vue'
import { ref } from 'vue'

export default {
    components: {
        Input,
        Button,
    },

    setup() {
        const form = ref({
            username: '',
            password: ''
        });

        return{
            form
        }
    }

}

</script>

<style>
.wrap3{
    height: 88vh;
}
</style>

