<template>
<div class="homeWrapper pt-4">
    <Logo/>
    <Searchbar/>

    <div class="w-full">
        <div class="border rounded-lg container mx-auto px-4 py-3 w-10/12 sm:w-9/12 md:w-6/12 lg:w-5/12">
            <span class="text-slate-400 text-sm">
                Search Results (5):
            </span>
            <ul>
                <li class="text-slate-200 mb-2 underline-offset-2 underline">
                    Thermodynamics Past Question
                </li>
            </ul>
        </div>
    </div>
</div>
</template>

<script>

import Logo from '../components/Logo.vue'
import Searchbar from '../components/Searchbar.vue'


export default{


    components: {
        Logo,
        Searchbar
    }
}
</script>

<style>
.homeWrapper{
    height: 88vh;
}
</style>